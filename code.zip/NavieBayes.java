
public class NavieBayes {
	private String doc;
	private String word;
	private String classOfDoc;
	public String getDoc() {
		return doc;
	}
	public void setDoc(String doc) {
		this.doc = doc;
	}

	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getClassOfDoc() {
		return classOfDoc;
	}
	public void setClassOfDoc(String classOfDoc) {
		this.classOfDoc = classOfDoc;
	}
}
