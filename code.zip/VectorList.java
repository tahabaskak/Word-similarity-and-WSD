
public class VectorList {
	private String vector;
	private int vectorCount;
	private String domain;
	public String getVector() {
		return vector;
	}
	public void setVector(String vector) {
		this.vector = vector;
	}
	public int getVectorCount() {
		return vectorCount;
	}
	public void setVectorCount(int vectorCount) {
		this.vectorCount = vectorCount;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
}
