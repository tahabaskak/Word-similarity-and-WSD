import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> trainWords = new ArrayList<String>();
		ArrayList<String> stemmerWords = new ArrayList<String>();
		ArrayList<String> testWords = new ArrayList<String>();
		ArrayList<String> wordsForCosineSimulary = new ArrayList<String>();
		ArrayList<String> splitTrainWords = new ArrayList<String>();
		ArrayList<String> splitStemmerWords = new ArrayList<String>();
		ArrayList<String> splitTestWords = new ArrayList<String>();
		ArrayList<String> splitWordsForCosineSimulary = new ArrayList<String>();
		ArrayList<String> classNumbers = new ArrayList<String>();
		ArrayList<String> differentWordsList = new ArrayList<String>();
		ArrayList<String> domainNames = new ArrayList<String>();
		ArrayList<NavieBayes> navieBayesWords = new ArrayList<NavieBayes>();
		ArrayList<NavieBayes> testWordsNavieBayes = new ArrayList<NavieBayes>();
		ArrayList<CosineSimilarity> words = new ArrayList<CosineSimilarity>();
		ArrayList<VectorList> vectors = new ArrayList<VectorList>();
		BufferedWriter output = null;
		File file = new File("output.txt");
		try {
			output = new BufferedWriter(new FileWriter(file));

			String trainWord = "train.txt";
			String stemmerWord = "vocabulary.txt";
			String testWord = "test.txt";
			String cosineSimularyText = "input.txt";
			// Task one start
			Stemmer.main(stemmerWord,stemmerWords);								// Find stem for vocabulary.txt
			Stemmer.main(trainWord,trainWords);									// Find stem for train.txt
			Stemmer.main(testWord,testWords);									// Find stem for test.txt
			splittingForStemmerVocabulary(stemmerWords,splitStemmerWords);		// Found stem for vocabulary.txt , splitting
			splittingForText(trainWords, splitTrainWords);					// Found stem for train.txt , splitting
			splittingForText(testWords, splitTestWords);						// Found stem for test.txt , splitting
			createNavieBayesInformation(splitTrainWords, navieBayesWords);		// creating Doc, words and class name for train.txt
			createNavieBayesInformation(splitTestWords, testWordsNavieBayes);						// creating Doc , words for test.txt
			setClassNumber(navieBayesWords,classNumbers);						// setting all words class name for train.txt
			choiceClass(navieBayesWords, testWordsNavieBayes, splitStemmerWords, classNumbers);		// Choice a class sentence for test.txt 
			setClassNumber(testWordsNavieBayes,classNumbers);					// setting all words and sentence class name for test.txt
			printTestText(testWordsNavieBayes, output);							// Printing task one results
			//Task one end
			
			// Task two start
			Stemmer.main(cosineSimularyText, wordsForCosineSimulary);			// Find stem for task two
			splittingForCosineSimularity(wordsForCosineSimulary, splitWordsForCosineSimulary);	// Found stem after splitting
			informationCosineSimilarity(splitWordsForCosineSimulary, words);	// Find +-3 words for a domain 
			differentWordsAndDomainName(words,differentWordsList,domainNames );	// Found words before step after, find different words and domainNames
			createInformationForVectorList(vectors, words, differentWordsList, domainNames);	// Create Vector List
			calculateCosine(vectors, domainNames, differentWordsList,output);	// Calculate Cosine similarity and printing
			//Task two end		
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				output.close();												//Close output.txt
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void printTestText(ArrayList<NavieBayes> testWordsNavieBayes,BufferedWriter output) throws IOException{
		String doc = null;
		output.write("Task one results : \r\n\r\n");
		for(NavieBayes s: testWordsNavieBayes){
			if(doc == null){
				doc = s.getDoc();
				output.write(s.getDoc() + " " + s.getClassOfDoc() + "\r\n");
			}
			else{
				if(!doc.equals(s.getDoc())){
					doc = s.getDoc();
					output.write(s.getDoc() + " " + s.getClassOfDoc()+ "\r\n");
				}
			}
		}
		output.write("\r\n");
	}
	
	public static void calculateCosine(ArrayList<VectorList> vectors,ArrayList<String> domainNames,ArrayList<String> differentWordsList,BufferedWriter output) throws IOException{
		double up = 1.0;
		double sumUp = 0.0;
		for(String s : differentWordsList){					// Find x1.x2 every element in list (x1 = word in a domain, x2 = word in a another domain)
			for(String d : domainNames){
				for(VectorList v : vectors){
					if(v.getVector().equals(s) && v.getDomain().equals(d)){
						up *= (double)v.getVectorCount();
					}
				}
			}
			sumUp += up;
			up = 1.0;
		}
		double down = 0.0;
		double sumDown = 1.0;
		for(String d : domainNames){						// Find x1.x1 every element in list
			for(String s : differentWordsList){
				for(VectorList v : vectors){
					if(v.getVector().equals(s) && v.getDomain().equals(d)){
						down += (double)v.getVectorCount()*(double)v.getVectorCount();
					}
				}
			}
			sumDown *= Math.sqrt(down);					
		}
		
		double result = sumUp / sumDown;				// result calculate cosine similarity
		output.write("Task one results : \r\n\r\n");	// output
		output.write("This two Words :( ");
		for(String s: domainNames){
			output.write(s + " ");
		}
		output.write( ") Cosine similarity between each other = " +result);
	}
	
	public static void createInformationForVectorList(ArrayList<VectorList> vectors,ArrayList<CosineSimilarity> words,ArrayList<String> differentWordsList,ArrayList<String> domainNames){
		VectorList newVector;
		int count=0;
		for(String s : domainNames){					// Find every vector and vector's information 
			for(String s2: differentWordsList){
				for(CosineSimilarity c : words){
					if(s.equals(c.getDomain()) && s2.equals(c.getWord())){
						count++;
					}
				}
				newVector = new VectorList();
				newVector.setDomain(s);
				newVector.setVector(s2);
				newVector.setVectorCount(count);
				vectors.add(newVector);
				count = 0;
			}
		}
	}
	
	public static void differentWordsAndDomainName(ArrayList<CosineSimilarity> words , ArrayList<String> differentWordsList,ArrayList<String> domainNames ){
		for(CosineSimilarity c : words){				
			if(!differentWordsList.contains(c.getWord())){			// Find different words
				differentWordsList.add(c.getWord());
			}
		}
		for(CosineSimilarity c : words){
			if(!domainNames.contains(c.getDomain())){				// Find different domain
				domainNames.add(c.getDomain());
			}
		}
	}

	public static void informationCosineSimilarity(ArrayList<String> splitWordsForCosineSimulary,ArrayList<CosineSimilarity> words){
		CosineSimilarity newCosine ;
		String domainName = null;
		for(int i = 0; i<splitWordsForCosineSimulary.size() ; i++){
			if(splitWordsForCosineSimulary.get(i).contains(":")){						// find domain name
				domainName = splitWordsForCosineSimulary.get(i);
				domainName= domainName.substring(0, domainName.length() - 1);			// remove last character in domain name (:)
			}else{
				if(splitWordsForCosineSimulary.get(i).contains(domainName)){			// if a word is domain name , after looking +-3 word
					if(splitWordsForCosineSimulary.get(i).endsWith("?") ||				// if word is last element in sentence, look before word
						splitWordsForCosineSimulary.get(i).endsWith("!") ||
						splitWordsForCosineSimulary.get(i).endsWith(".") ){
						if(i-1 >= 0){													// control first and last element in array list
							if( !splitWordsForCosineSimulary.get(i-1).endsWith("!") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith("?") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith(".") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith(":") ){	
								if(!splitWordsForCosineSimulary.get(i-1).endsWith(":")){	// if word include ":" , so is domain  
									newCosine = new CosineSimilarity();
									newCosine.setDomain(domainName);
									newCosine.setWord(splitWordsForCosineSimulary.get(i-1));
									words.add(newCosine);
								}
								if(i-2 >= 0){													// control first and last element in array list
									if( !splitWordsForCosineSimulary.get(i-2).endsWith("!") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith("?") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith(".") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith(":") ){
										if(!splitWordsForCosineSimulary.get(i-2).endsWith(":")){		// if word include ":" , so is domain 
											newCosine = new CosineSimilarity();
											newCosine.setDomain(domainName);
											newCosine.setWord(splitWordsForCosineSimulary.get(i-2));
											words.add(newCosine);
										}
										if(i-3 >= 0){													// control first and last element in array list
											if( !splitWordsForCosineSimulary.get(i-3).endsWith("!") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith("?") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith(".") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith(":") ){
												if(!splitWordsForCosineSimulary.get(i-3).endsWith(":")){		// if word include ":" , so is domain 
													newCosine = new CosineSimilarity();
													newCosine.setDomain(domainName);
													newCosine.setWord(splitWordsForCosineSimulary.get(i-3));
													words.add(newCosine);
												}
											}
										}
									}
								}
							}
						}
					}else{
						if(i-1 >= 0){														// control first and last element in array list
							if( !splitWordsForCosineSimulary.get(i-1).endsWith("!") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith("?") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith(".") ||
								!splitWordsForCosineSimulary.get(i-1).endsWith(":") ){
								if(!splitWordsForCosineSimulary.get(i-1).endsWith(":")){		// if word include ":" , so is domain 
									newCosine = new CosineSimilarity();
									newCosine.setDomain(domainName);
									newCosine.setWord(splitWordsForCosineSimulary.get(i-1));
									words.add(newCosine);
								}
								if(i-2 >= 0){												// control first and last element in array list
									if( !splitWordsForCosineSimulary.get(i-2).endsWith("!") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith("?") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith(".") ||
										!splitWordsForCosineSimulary.get(i-2).endsWith(":") ){
										if(!splitWordsForCosineSimulary.get(i-2).endsWith(":")){	// if word include ":" , so is domain 
											newCosine = new CosineSimilarity();
											newCosine.setDomain(domainName);
											newCosine.setWord(splitWordsForCosineSimulary.get(i-2));
											words.add(newCosine);
										}
										if(i-3 >= 0){														// control first and last element in array list
											if( !splitWordsForCosineSimulary.get(i-3).endsWith("!") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith("?") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith(".") ||
												!splitWordsForCosineSimulary.get(i-3).endsWith(":") ){
												if(!splitWordsForCosineSimulary.get(i-3).endsWith(":")){	// if word include ":" , so is domain 
													newCosine = new CosineSimilarity();
													newCosine.setDomain(domainName);
													newCosine.setWord(splitWordsForCosineSimulary.get(i-3));
													words.add(newCosine);
												}
											}
										}
									}
								}
							}
						}
						if(i+1<splitWordsForCosineSimulary.size()){						// control first and last element in array list
							if( !splitWordsForCosineSimulary.get(i+1).endsWith("!") ||
								!splitWordsForCosineSimulary.get(i+1).endsWith("?") ||
								!splitWordsForCosineSimulary.get(i+1).endsWith(".") ||
								!splitWordsForCosineSimulary.get(i+1).endsWith(":") ){
								if(!splitWordsForCosineSimulary.get(i+1).endsWith(":")){	// if word include ":" , so is domain 
									newCosine = new CosineSimilarity();
									newCosine.setDomain(domainName);
									newCosine.setWord(splitWordsForCosineSimulary.get(i+1));
									words.add(newCosine);
								}
								if(i+2<splitWordsForCosineSimulary.size()){						// control first and last element in array list
									if( !splitWordsForCosineSimulary.get(i+2).endsWith("!") ||
										!splitWordsForCosineSimulary.get(i+2).endsWith("?") ||
										!splitWordsForCosineSimulary.get(i+2).endsWith(".") ||
										!splitWordsForCosineSimulary.get(i+2).endsWith(":") ){
										if(!splitWordsForCosineSimulary.get(i+2).endsWith(":")){	// if word include ":" , so is domain 
											newCosine = new CosineSimilarity();
											newCosine.setDomain(domainName);
											newCosine.setWord(splitWordsForCosineSimulary.get(i+2));
											words.add(newCosine);
										}
										if(i+3<splitWordsForCosineSimulary.size()){						// control first and last element in array list
											if( !splitWordsForCosineSimulary.get(i+3).endsWith("!") ||
												!splitWordsForCosineSimulary.get(i+3).endsWith("?") ||
												!splitWordsForCosineSimulary.get(i+3).endsWith(".") ||
												!splitWordsForCosineSimulary.get(i+3).endsWith(":") ){
												if(!splitWordsForCosineSimulary.get(i+3).endsWith(":")){	// if word include ":" , so is domain 
													newCosine = new CosineSimilarity();	
													newCosine.setDomain(domainName);
													newCosine.setWord(splitWordsForCosineSimulary.get(i+3));
													words.add(newCosine);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public static void choiceClass(ArrayList<NavieBayes> navieBayesWords,ArrayList<NavieBayes> testWordsNavieBayes,ArrayList<String> splitStemmerWords,ArrayList<String> classNumbers){
		String doc = null;
		double classNumber1 = 0.5;
		double classNumber2 = 0.5;
		for(int i=0 ; i<testWordsNavieBayes.size();i++){
			if(doc == null){
				doc = testWordsNavieBayes.get(i).getDoc();										// First sentence a doc name
			}else{
				if(!doc.equals(testWordsNavieBayes.get(i).getDoc())){
					doc = testWordsNavieBayes.get(i).getDoc();									// New doc name a sentence
					if(Double.compare(classNumber1, classNumber2) < 0){							// Find created which class
						testWordsNavieBayes.get(i-1).setClassOfDoc(classNumbers.get(1));		// and write probability
					}else if(Double.compare(classNumber1, classNumber2) > 0)
						testWordsNavieBayes.get(i-1).setClassOfDoc(classNumbers.get(0));
					classNumber1 = 0.5;								
					classNumber2 = 0.5;
				}
				classNumber1 *= calculeter(testWordsNavieBayes.get(i).getWord(), splitStemmerWords.size(),classNumbers.get(0), navieBayesWords);
				classNumber2 *= calculeter(testWordsNavieBayes.get(i).getWord(), splitStemmerWords.size(),classNumbers.get(1), navieBayesWords);
				if(i == testWordsNavieBayes.size()-1){											// write last doc name probability
					if(Double.compare(classNumber1, classNumber2) < 0){
						testWordsNavieBayes.get(i-1).setClassOfDoc(classNumbers.get(1));		// New doc name a sentence
					}else if(Double.compare(classNumber1, classNumber2) > 0)
						testWordsNavieBayes.get(i-1).setClassOfDoc(classNumbers.get(0));		// Find created which class
					classNumber1 = 0.5;
					classNumber2 = 0.5;
				}
			}	
		}
	}
	
	public static double calculeter(String word,int vCount,String classNumber,ArrayList<NavieBayes> navieBayesWords){
		int countWord = 0;
		double result = 0.0;
		for(int i = 0 ; i< navieBayesWords.size() ; i++){
			if(word.equals(navieBayesWords.get(i).getWord()) && classNumber.equals(navieBayesWords.get(i).getClassOfDoc()) ){
				countWord++;														// Find word count with same class name
			}
		}
		int classCount = classWordCount(navieBayesWords, classNumber);				// Find word count in a class
		result = (double)(1+countWord)/(double)(classCount+vCount);					// Calculate probability create a word in a class
		return result;																// return probability
	}
	
	public static int classWordCount(ArrayList<NavieBayes> navieBayesWords,String classNumber){
		int count = 0;
		for(int i =0 ; i<navieBayesWords.size();i++){
			if(classNumber.equals(navieBayesWords.get(i).getClassOfDoc()))		// Find words in a class name
				count++;
		}
		return count;															// Return word count in a class name
	}
	
	public static void setClassNumber(ArrayList<NavieBayes> navieBayesWords,ArrayList<String> classNumbers){
		String classNumber = null;
		String doc = null ; 
		
		for(int i = 0 ; i<navieBayesWords.size();i++){
			if(navieBayesWords.get(i).getClassOfDoc() != null){		
				classNumber = navieBayesWords.get(i).getClassOfDoc();				// Adding class name location variable
				if(classNumbers.isEmpty()){								
					classNumbers.add(classNumber);									// Adding class name array list
				}
				else{
					if(!classNumbers.contains(classNumber))							// Find Another class name after adding
						classNumbers.add(classNumber);
				}
				doc = navieBayesWords.get(i).getDoc();								// Adding doc name location variable
				for(int j =0 ; j<navieBayesWords.size();j++){
					if(doc.equals(navieBayesWords.get(j).getDoc())){
						navieBayesWords.get(j).setClassOfDoc(classNumber);			// Add all word class name
					}
				}
			}
		}
	}
		
	public static void createNavieBayesInformation(ArrayList<String> splitTrainWords,ArrayList<NavieBayes> navieBayesWords){
		NavieBayes newNavieBayes;										// Create new element For NavieBayes class
		for(int i = 0 ; i<splitTrainWords.size();i++){
			if(splitTrainWords.get(i).contains("800")){					// Find Doc name
				for(int j=i+1;j<splitTrainWords.size();j++){
					if(splitTrainWords.get(j).contains("800")){			// Another doc name
						break;											// So break for and continue
					}
					else{		
						newNavieBayes = new NavieBayes();				
						newNavieBayes.setDoc(splitTrainWords.get(i));		// set doc name
						if(splitTrainWords.get(j).contains("512")){			// set class name
							newNavieBayes.setClassOfDoc(splitTrainWords.get(j));	
						}else{
							newNavieBayes.setWord(splitTrainWords.get(j));	// set words
						}
						navieBayesWords.add(newNavieBayes);					// add element NavieBayes list
					}
				}
			}
		}
	}

	public static void splittingForText(ArrayList<String> trainWords,ArrayList<String> splitTrainWords){
		for(int i = 0 ; i<trainWords.size();i++){				// Spliting for train.txt
			if(!trainWords.get(i).isEmpty()){
				String[] splitString = trainWords.get(i).trim().split("[\\ \\.\\,\\\n\\\t\\<\\>\\/\\:\\(\\)\\#\\&\\{\\}\\-\\\"]");
				for(int j=0; j<splitString.length ; j++){
					if(!splitString[j].isEmpty()){
						splitTrainWords.add(splitString[j].trim());
					}
				}
			}
		}
	}
	
	public static void splittingForStemmerVocabulary(ArrayList<String> stemmerWords,ArrayList<String> splitStemmerWords){
		String[] splitString = stemmerWords.get(0).split("[\\,\\ \\\n]");		// Splitting for vocabulary.txt
		for(int i=0; i<splitString.length ; i++){
			if(!splitString[i].isEmpty()){
				splitStemmerWords.add(splitString[i]);		
			}
		}
	}
	
	public static void splittingForCosineSimularity(ArrayList<String> wordsForCosineSimulary,ArrayList<String> splitWordsForCosineSimulary){
		for(int i = 0 ; i<wordsForCosineSimulary.size();i++){				// Splitting for cosine similarity input
			if(!wordsForCosineSimulary.get(i).isEmpty()){
				String[] splitString = wordsForCosineSimulary.get(i).trim().split("[\\,\\ \\\n]");
				for(int j=0; j<splitString.length ; j++){
					if(!splitString[j].isEmpty()){
						splitWordsForCosineSimulary.add(splitString[j].trim());
					}
				}
			}
		}
	}
	
}
